VERSION = '0.1.5'

def get_version():
    print 'Pendulum %s' % VERSION